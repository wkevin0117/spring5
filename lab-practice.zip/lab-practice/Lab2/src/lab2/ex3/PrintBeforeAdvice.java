package lab2.ex3;

import org.aspectj.lang.JoinPoint;

public class PrintBeforeAdvice {
	
	public void before(JoinPoint jointPoint) {
	
	}
}
