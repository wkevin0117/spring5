package lab2.ex1;

public class Task2Client {

	public static void main(String[] args) {
		// -- Lab Ex1 Task2-1 Start -- //
		// -- Lab Ex1 Task2-1 End -- //
        // -- Lab Ex1 Task2-3 Start -- //
        // -- Lab Ex1 Task2-3 End -- //		
	}

}
