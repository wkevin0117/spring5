package lab2.ex1;

public class SetterInjectionProductViewer implements ProductViewer{

    public void showProduct()
    {
        
    }
	
}
