package lab2.ex1;

public class ConstructorInjectionProductViewer implements ProductViewer {

    public void showProduct()
    {
        
    }

}
