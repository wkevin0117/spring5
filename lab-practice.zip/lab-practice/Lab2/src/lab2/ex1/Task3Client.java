package lab2.ex1;


public class Task3Client {

	public static void main(String[] args) {
		// -- Lab Ex1 Task3-1 Start -- //
        // -- Lab Ex1 Task3-1 End -- //
	}

}
