package lab2.ex1;

public interface ProductViewer {
	public void showProduct();
}
