package lab3.ex2;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProductRowMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int rowCount) throws SQLException {
		
		return null;
	}

}
