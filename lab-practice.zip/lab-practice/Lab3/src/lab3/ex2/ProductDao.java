package lab3.ex2;

public interface ProductDao
{

}
