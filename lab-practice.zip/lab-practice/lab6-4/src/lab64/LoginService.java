package lab64;

public interface LoginService {
	public boolean login(String user, String password);
}
