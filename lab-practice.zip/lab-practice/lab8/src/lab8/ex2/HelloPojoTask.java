package lab8.ex2;

import java.util.Date;

public class HelloPojoTask {
	
	public void hello() {
		System.out.println("Hello World from POJO! at time:" + new Date());
	}

}
